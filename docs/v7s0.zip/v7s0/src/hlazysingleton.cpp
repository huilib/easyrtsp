

#include "hlazysingleton.h"