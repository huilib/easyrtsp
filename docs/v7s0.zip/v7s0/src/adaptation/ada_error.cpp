

#include "ada_error.h"

namespace HUICPP {

namespace adapt {

// HRET inline hstrerror(HN errnum, HSZ buf, HSIZE buflen) {

//     HASSERT_RETURN(strerror_r(errnum, buf, buflen) == 0, SYS_FAILED);

//     HRETURN_OK;
// }


}

}