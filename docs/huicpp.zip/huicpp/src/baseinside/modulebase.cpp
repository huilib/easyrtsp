

#include "modulebase.h"



namespace HUICPP {

namespace BASEINSIDE {


ModuleBase::ModuleBase(HCSTRR strModuleName) noexcept
    : m_strModuleName(strModuleName) {

}



ModuleBase::~ ModuleBase() noexcept {
    
}



}

}

