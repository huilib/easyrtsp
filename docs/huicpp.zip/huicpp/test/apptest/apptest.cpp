

#include "testapp.h"

int main(int argc, const char* argv[]) {

    TestApp app(argc, argv);

    app.Run();

    return 0;
}